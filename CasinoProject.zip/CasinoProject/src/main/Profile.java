package main;

public class Profile {
	
	public int money =0;
	public String name="";
	
	public Profile(int money, String name){
		this.money=money;
		this.name=name;
	}

}
